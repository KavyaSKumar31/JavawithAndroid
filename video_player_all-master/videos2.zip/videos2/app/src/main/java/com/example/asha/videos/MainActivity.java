package com.example.asha.videos;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {
    VideoView video;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        video=(VideoView)findViewById(R.id.videoView);
        MediaController m = new MediaController(this);
        video.setMediaController(m);
        String path="android.resource://com.example.asha.videos/"+R.raw.fall_background_video;
        Uri uri=Uri.parse(path);
        video.setVideoURI(uri);
        video.start();
    }
}
