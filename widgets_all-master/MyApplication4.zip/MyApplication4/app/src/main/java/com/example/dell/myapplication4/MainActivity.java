package com.example.dell.myapplication4;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.RotateAnimation;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    TextView textView1, textView2, textView3, textView4;
    ImageView img;
    Switch swt;
    SeekBar sk;
    RadioGroup r1;
    RadioButton rb1, rb2;
    ToggleButton toggle;
    LinearLayout linear;
    CheckBox chk;
    Animation anim;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // toggle = (ToggleButton) findViewById(R.id.button);
        toggle = (ToggleButton) findViewById(R.id.button);
        linear = (LinearLayout) findViewById(R.id.linear);

        sk = (SeekBar) findViewById(R.id.seekBar3);
        textView3 = (TextView) findViewById(R.id.textView11);
        toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    linear.setBackgroundResource(R.drawable.ic_launcher_background);
                } else {
                    linear.setBackgroundResource(R.drawable.ic_launcher_foreground);
                }


            }

        });

        chk = (CheckBox) findViewById(R.id.checkBox);
        textView1 = (TextView) findViewById(R.id.textView3);
        chk.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    textView1.setText("CheckBox is selected");
                } else {
                    textView1.setText("Not selected");

                }
            }
        });
        r1 = (RadioGroup) findViewById(R.id.radio);
        rb1 = (RadioButton) findViewById(R.id.radioButton);
        textView2 = (TextView) findViewById(R.id.textView8);
        rb2 = (RadioButton) findViewById(R.id.radioButton2);
        rb1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (rb1.getId() == R.id.radioButton) {
                    textView2.setText("female");
                }


            }
        });


        rb2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (rb2.getId() == R.id.radioButton2) {
                    textView2.setText("male");
                }


            }
        });

        sk.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
         //   int p = 0;

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

               /* if (p < 30) {
                    p = 30;
                    sk.setProgress(p);
                }*/
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

               // p = progress;
                textView3.setTextSize(progress);
            }

        });
        img = (ImageView) findViewById(R.id.imageView);
        swt = (Switch) findViewById(R.id.switch2);
        swt.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(b)
                {
                    ImageView animationTarget = (ImageView) findViewById(R.id.imageView);
                    anim = AnimationUtils.loadAnimation(MainActivity.this, R.anim.rotate1);
                    animationTarget.startAnimation(anim);
                }

                else
                {


                }

            }
        });

    }
}