package com.example.sms.color;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
private EditText edit;
Button red,blue,green;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edit=(EditText)findViewById(R.id.editText);
       red=(Button)findViewById(R.id.button);
       blue=(Button)findViewById(R.id.button3);
       green=(Button)findViewById(R.id.button2);
        edit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String color = edit.getText().toString();
                String[] items = color.split(",");
                for (int i = 0; i < items.length; i++) {
                    if (items[i].equals("red")) {
                        red.setBackgroundColor(Color.RED);
                    }
                    if (items[i].equals("blue")) {
                        blue.setBackgroundColor(Color.BLUE);


                    }
                    if (items[i].equals("green")) {
                        green.setBackgroundColor(Color.GREEN);
                    }
                }
            }
        });
    }
}
