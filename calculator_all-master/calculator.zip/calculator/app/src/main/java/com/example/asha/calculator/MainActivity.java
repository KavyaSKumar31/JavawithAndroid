package com.example.asha.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button button,button2,button3,button4;
    TextView text;
    EditText edit,edit1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button=(Button) findViewById(R.id.button);
        button2=(Button) findViewById(R.id.button2);
        button3=(Button) findViewById(R.id.button3);
        button4=(Button) findViewById(R.id.button4);
        text=(TextView)findViewById(R.id.textView);
        edit=(EditText)findViewById(R.id.editText);
        edit1=(EditText)findViewById(R.id.editText2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String one = edit.getText().toString();
                String two = edit1.getText().toString();
                int a = Integer.parseInt(one);
                int b = Integer.parseInt(two);
                int c = a + b;
                text.setText(Integer.toString(c));
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String one = edit.getText().toString();
                String two = edit1.getText().toString();
                int a = Integer.parseInt(one);
                int b = Integer.parseInt(two);
                int c = a - b;
                text.setText(Integer.toString(c));
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String one = edit.getText().toString();
                String two = edit1.getText().toString();
                int a = Integer.parseInt(one);
                int b = Integer.parseInt(two);
                int c = a * b;
                text.setText(Integer.toString(c));
            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String one = edit.getText().toString();
                String two = edit1.getText().toString();
                int a = Integer.parseInt(one);
                int b = Integer.parseInt(two);
                try{
                    int c = a / b;
                    text.setText(Integer.toString(c));
                }
                catch (Exception e){
                    Toast.makeText(MainActivity.this,"cant di vide by 0",Toast.LENGTH_LONG).show();
                }


            }
        });

    }
}
